const produtos = document.getElementById("produtos");

const image = ["Imagens/cadeira escritorio.PNG", "Imagens/moletom.PNG", "Imagens/JBL.PNG", "Imagens/jogo de cama.PNG", "Imagens/IPHONE.PNG", "Imagens/una.Png"];
const azul = ["OFERTA DO DIA"];
const mensagens = ["Cadeira Escritório Ergonômica Genebra B500 Luvinco Cor Preto Com Suporte Lombar Estofado Mesh", "Moletom Bege Canguru Estampa Frente Borboleta Colorida", "Caixa de Som Bluetooth À Prova D'água Boombox 4 JBL - Preta", "Jogo De Cama Micro Cotton Camesa 4 Pçs Casal", "Apple iPhone 15 (128 GB) - Rosa - Distribuidor Autorizado", "Deo Parfum Natura Una Instinct 75ml"];
const preco = ["R$599,00", "R$39,90", "R$2.916,45", "R$131,70", "R$4.099,57", "R$223,17"];
const verde = ["Chegará grátis amanhã"];

for (let i = 0; i < image.length; i++) {
    produtos.innerHTML += `
    <div class="parte1">
        <div class="espacodaImg">
            <img class="img" src="${image[i]}"
        </div>
        <div class="espaco azul">
            <p>${azul}</p>
        </div>
        <div class="espaco1">
            <p>${mensagens[i]}</p>
        </div>
        <div class="espaco1 preco">
            <h3>${preco[i]}</h3>
        </div>
        <div class="verde1">
            <p class="verde">${verde}</p>
            <img src="Imagens/full.png">
        </div>
    </div>
    `
}